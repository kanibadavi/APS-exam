// todo: there is a div tag with "colorChangeElement" id. Create a script that handles mouseover and mouseout events to change the background color of this element.

//Answer
